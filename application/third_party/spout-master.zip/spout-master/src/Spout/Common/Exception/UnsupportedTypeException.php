<?php

namespace Box\Spout\Common\Exception;

/**
 * Class UnsupportedTypeException
 */
class UnsupportedTypeException extends SpoutException
{
}
