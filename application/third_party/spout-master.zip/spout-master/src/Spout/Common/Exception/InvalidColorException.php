<?php

namespace Box\Spout\Common\Exception;

/**
 * Class InvalidColorException
 */
class InvalidColorException extends SpoutException
{
}
